import App from "./login";
import App2 from "./paginalogada";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from '@react-navigation/native-stack';


const stack = createNativeStackNavigator();

export default function Pagina() {

  return (
    <NavigationContainer>
      <stack.Navigator>
        <stack.Screen name="Login" component={App} options={{headerShown: false}}/>
        <stack.Screen name="Logado" component={App2} options={{headerShown: false}}/>
      </stack.Navigator>
    </NavigationContainer>
  );
}